﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using DairyERP.Data;
using DairyERP.Models;

namespace DairyERP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        private readonly DairyDbContext _context;

        public ReportsController(DairyDbContext context)
        {
            _context = context;
        }

        [HttpGet("daily-collection-summary")]
        public async Task<IActionResult> GetDailyCollectionSummary([FromQuery] DateTime date)
        {
            try
            {
                var summary = await _context.MilkCollections
                    .Include(m => m.CollectionCenter)
                    .Where(m => m.CollectionDate.Date == date.Date)
                    .GroupBy(m => m.CenterID)
                    .Select(g => new
                    {
                        CenterID = g.Key,
                        CenterName = g.First().CollectionCenter != null ?
                                   g.First().CollectionCenter.CenterName : "No Center",
                        TotalQuantity = g.Sum(m => m.Quantity),
                        // FIXED: Added ?? 0 to handle null TotalAmount
                        TotalAmount = g.Sum(m => m.TotalAmount ?? 0),
                        AverageFat = g.Average(m => m.FatPercentage),
                        CollectionCount = g.Count()
                    })
                    .ToListAsync();

                return Ok(summary);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("farmer-payment-summary")]
        public async Task<IActionResult> GetFarmerPaymentSummary(
            [FromQuery] DateTime fromDate,
            [FromQuery] DateTime toDate,
            [FromQuery] int? farmerId = null)
        {
            try
            {
                var query = _context.MilkCollections
                    .Include(m => m.Farmer)
                    .Where(m => m.CollectionDate.Date >= fromDate.Date &&
                               m.CollectionDate.Date <= toDate.Date &&
                               !m.IsPaid);

                if (farmerId.HasValue)
                {
                    query = query.Where(m => m.FarmerID == farmerId.Value);
                }

                var summary = await query
                    .GroupBy(m => new { m.FarmerID, m.Farmer.FullName })
                    .Select(g => new FarmerPaymentSummary
                    {
                        FarmerID = g.Key.FarmerID,
                        FarmerName = g.Key.FullName ?? "Unknown",
                        TotalQuantity = g.Sum(m => m.Quantity),
                        // FIXED: Added ?? 0 to handle null TotalAmount
                        TotalAmount = g.Sum(m => m.TotalAmount ?? 0),
                        CollectionsCount = g.Count()
                    })
                    .OrderByDescending(s => s.TotalAmount)
                    .ToListAsync();

                return Ok(summary);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        // ... rest of the code remains the same
    }

    public class FarmerPaymentSummary
    {
        public int FarmerID { get; set; }
        public string FarmerName { get; set; } = string.Empty;
        public decimal TotalQuantity { get; set; }
        public decimal TotalAmount { get; set; }
        public int CollectionsCount { get; set; }
    }

    public class SalesReport
    {
        public string InvoiceNumber { get; set; } = string.Empty;
        public DateTime InvoiceDate { get; set; }
        public string CustomerName { get; set; } = string.Empty;
        public string ProductName { get; set; } = string.Empty;
        public decimal Quantity { get; set; }
        public decimal TotalAmount { get; set; }
        public string PaymentStatus { get; set; } = string.Empty;
    }
}