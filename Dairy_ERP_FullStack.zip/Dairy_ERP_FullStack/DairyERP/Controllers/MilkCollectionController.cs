﻿using Microsoft.AspNetCore.Mvc;
using DairyERP.Interfaces;
using DairyERP.Models;

namespace DairyERP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MilkCollectionsController : ControllerBase
    {
        private readonly ICollectionService _collectionService;

        public MilkCollectionsController(ICollectionService collectionService)
        {
            _collectionService = collectionService;
        }

        [HttpPost("daily-collection")]
        public async Task<IActionResult> RecordCollection([FromBody] MilkCollection collection)
        {
            try
            {
                var result = await _collectionService.RecordCollectionAsync(collection);
                return Ok(result);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpGet("daily-report")]
        public async Task<IActionResult> GetDailyReport([FromQuery] DateTime date, [FromQuery] int? centerId)
        {
            try
            {
                var report = await _collectionService.GetDailyCollectionReportAsync(date, centerId);
                return Ok(report);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpPost("bulk-collection")]
        public async Task<IActionResult> RecordBulkCollection([FromBody] List<MilkCollection> collections)
        {
            try
            {
                var results = new List<MilkCollection>();
                foreach (var collection in collections)
                {
                    var result = await _collectionService.RecordCollectionAsync(collection);
                    results.Add(result);
                }
                return Ok(results);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpGet("farmer-summary/{farmerId}")]
        public async Task<IActionResult> GetFarmerCollectionSummary(
            int farmerId,
            [FromQuery] DateTime fromDate,
            [FromQuery] DateTime toDate)
        {
            try
            {
                var summary = await _collectionService.GetFarmerCollectionSummaryAsync(farmerId, fromDate, toDate);
                return Ok(summary);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }
    }
}