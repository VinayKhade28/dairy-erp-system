﻿using Microsoft.AspNetCore.Mvc;
using DairyERP.Services;
using DairyERP.Models;
using DairyERP.DTOs;
using DairyERP.Interfaces;

namespace DairyERP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FarmersController : ControllerBase
    {
        private readonly IFarmerService _farmerService;

        public FarmersController(IFarmerService farmerService)
        {
            _farmerService = farmerService;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllFarmers()
        {
            try
            {
                var farmers = await _farmerService.GetAllFarmersAsync();
                return Ok(farmers);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetFarmer(int id)
        {
            try
            {
                var farmer = await _farmerService.GetFarmerByIdAsync(id);
                if (farmer == null)
                    return NotFound(new { message = $"Farmer with ID {id} not found" });

                return Ok(farmer);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> CreateFarmer([FromBody] Farmer farmer)
        {
            try
            {
                if (!ModelState.IsValid)
                    return BadRequest(ModelState);

                var createdFarmer = await _farmerService.CreateFarmerAsync(farmer);
                return CreatedAtAction(nameof(GetFarmer), new { id = createdFarmer.FarmerID }, createdFarmer);
            }
            catch (Exception ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFarmer(int id, [FromBody] Farmer farmer)
        {
            try
            {
                if (id != farmer.FarmerID)
                    return BadRequest(new { error = "ID mismatch" });

                await _farmerService.UpdateFarmerAsync(farmer);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteFarmer(int id)
        {
            try
            {
                await _farmerService.DeleteFarmerAsync(id);
                return NoContent();
            }
            catch (KeyNotFoundException ex)
            {
                return NotFound(new { error = ex.Message });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }

        [HttpGet("search")]
        public async Task<IActionResult> SearchFarmers([FromQuery] string searchTerm)
        {
            try
            {
                var farmers = await _farmerService.SearchFarmersAsync(searchTerm);
                return Ok(farmers);
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { error = ex.Message });
            }
        }
    }
}
