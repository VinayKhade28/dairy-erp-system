﻿using DairyERP.DTOs;

namespace DairyERP.Interfaces
{
    public interface IAuthService
    {
        Task<AuthResponseDTO> LoginAsync(LoginDTO loginDTO);
        Task<UserDTO> RegisterAsync(RegisterDTO registerDTO);
        Task<bool> ChangePasswordAsync(int userId, string oldPassword, string newPassword);
    }
}
