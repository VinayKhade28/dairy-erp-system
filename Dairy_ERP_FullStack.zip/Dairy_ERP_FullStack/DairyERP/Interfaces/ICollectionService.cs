﻿using DairyERP.Models;

namespace DairyERP.Interfaces
{
    public interface ICollectionService
    {
        Task<MilkCollection> RecordCollectionAsync(MilkCollection collection);
        Task<List<MilkCollection>> GetDailyCollectionReportAsync(DateTime date, int? centerId);
        Task<List<FarmerCollectionSummary>> GetFarmerCollectionSummaryAsync(int farmerId, DateTime fromDate, DateTime toDate);
    }

    public class FarmerCollectionSummary
    {
        public DateTime Date { get; set; }
        public decimal TotalQuantity { get; set; }
        public decimal? AverageFat { get; set; }
        public decimal? TotalAmount { get; set; }
    }
}