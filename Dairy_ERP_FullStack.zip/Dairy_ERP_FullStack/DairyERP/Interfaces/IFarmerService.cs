﻿using DairyERP.DTOs;
using DairyERP.Models;

namespace DairyERP.Interfaces
{
    public interface IFarmerService
    {
        Task<IEnumerable<FarmerDTO>> GetAllFarmersAsync();
        Task<FarmerDTO> GetFarmerByIdAsync(int id);
        Task<FarmerDTO> CreateFarmerAsync(Farmer farmer);
        Task UpdateFarmerAsync(Farmer farmer);
        Task DeleteFarmerAsync(int id);
        Task<IEnumerable<FarmerDTO>> SearchFarmersAsync(string searchTerm);
    }
}
