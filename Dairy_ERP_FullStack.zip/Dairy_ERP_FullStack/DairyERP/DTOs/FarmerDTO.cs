﻿namespace DairyERP.DTOs
{
    public class FarmerDTO
    {
        public int FarmerID { get; set; }
        public string FarmerCode { get; set; }
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public string Village { get; set; }
        public bool IsActive { get; set; }
    }

    public class CreateFarmerDTO
    {
        public string FarmerCode { get; set; }
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public string Village { get; set; }
        public string BankAccountNumber { get; set; }
    }

    public class UpdateFarmerDTO
    {
        public string FullName { get; set; }
        public string ContactNumber { get; set; }
        public string Village { get; set; }
        public bool IsActive { get; set; }
    }
}