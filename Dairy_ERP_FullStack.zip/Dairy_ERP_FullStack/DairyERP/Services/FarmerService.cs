﻿using DairyERP.Data;
using DairyERP.DTOs;
using DairyERP.Interfaces;
using DairyERP.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DairyERP.Services
{
    public class FarmerService : IFarmerService
    {
        private readonly DairyDbContext _context;
        private readonly ILogger<FarmerService> _logger;

        public FarmerService(DairyDbContext context, ILogger<FarmerService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<IEnumerable<FarmerDTO>> GetAllFarmersAsync()
        {
            try
            {
                var farmers = await _context.Farmers
                    .Where(f => f.IsActive)
                    .Select(f => new FarmerDTO
                    {
                        FarmerID = f.FarmerID,
                        FarmerCode = f.FarmerCode,
                        FullName = f.FullName,
                        ContactNumber = f.ContactNumber,
                        Village = f.Village,
                        IsActive = f.IsActive
                    })
                    .OrderBy(f => f.FarmerCode)
                    .ToListAsync();

                return farmers;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting all farmers");
                throw;
            }
        }

        public async Task<FarmerDTO> GetFarmerByIdAsync(int id)
        {
            try
            {
                var farmer = await _context.Farmers
                    .Where(f => f.FarmerID == id)
                    .Select(f => new FarmerDTO
                    {
                        FarmerID = f.FarmerID,
                        FarmerCode = f.FarmerCode,
                        FullName = f.FullName,
                        ContactNumber = f.ContactNumber,
                        Village = f.Village,
                        IsActive = f.IsActive
                    })
                    .FirstOrDefaultAsync();

                if (farmer == null)
                    throw new KeyNotFoundException($"Farmer with ID {id} not found");

                return farmer;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error getting farmer by ID: {id}");
                throw;
            }
        }
        public async Task<FarmerDTO> CreateFarmerAsync(Farmer farmer)
        {
            try
            {
                // Validate farmer code is unique
                var existingFarmer = await _context.Farmers
                    .FirstOrDefaultAsync(f => f.FarmerCode == farmer.FarmerCode);

                if (existingFarmer != null)
                    throw new ArgumentException($"Farmer with code {farmer.FarmerCode} already exists");

                // Set default values
                farmer.RegistrationDate = DateTime.UtcNow;
                farmer.IsActive = true;

                _context.Farmers.Add(farmer);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Created new farmer: {farmer.FullName} ({farmer.FarmerCode})");

                return new FarmerDTO
                {
                    FarmerID = farmer.FarmerID,
                    FarmerCode = farmer.FarmerCode,
                    FullName = farmer.FullName,
                    ContactNumber = farmer.ContactNumber,
                    Village = farmer.Village,
                    IsActive = farmer.IsActive
                };
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error creating farmer");
                throw;
            }
        }

        public async Task UpdateFarmerAsync(Farmer farmer)
        {
            try
            {
                var existingFarmer = await _context.Farmers.FindAsync(farmer.FarmerID);
                if (existingFarmer == null)
                    throw new KeyNotFoundException($"Farmer with ID {farmer.FarmerID} not found");

                // Update properties
                existingFarmer.FullName = farmer.FullName;
                existingFarmer.ContactNumber = farmer.ContactNumber;
                existingFarmer.Address = farmer.Address;
                existingFarmer.Village = farmer.Village;
                existingFarmer.BankAccountNumber = farmer.BankAccountNumber;
                existingFarmer.IFSCode = farmer.IFSCode;
                existingFarmer.IsActive = farmer.IsActive;

                _context.Farmers.Update(existingFarmer);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Updated farmer: {farmer.FullName} ({farmer.FarmerID})");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error updating farmer ID: {farmer.FarmerID}");
                throw;
            }
        }

        public async Task DeleteFarmerAsync(int id)
        {
            try
            {
                var farmer = await _context.Farmers.FindAsync(id);
                if (farmer == null)
                    throw new KeyNotFoundException($"Farmer with ID {id} not found");

                // Soft delete - set IsActive to false
                farmer.IsActive = false;
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Deleted (deactivated) farmer ID: {id}");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error deleting farmer ID: {id}");
                throw;
            }
        }

        public async Task<IEnumerable<FarmerDTO>> SearchFarmersAsync(string searchTerm)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(searchTerm))
                    return await GetAllFarmersAsync();

                searchTerm = searchTerm.ToLower();

                var farmers = await _context.Farmers
                    .Where(f => f.IsActive &&
                           (f.FullName.ToLower().Contains(searchTerm) ||
                            f.FarmerCode.ToLower().Contains(searchTerm) ||
                            f.ContactNumber.Contains(searchTerm) ||
                            f.Village.ToLower().Contains(searchTerm)))
                    .Select(f => new FarmerDTO
                    {
                        FarmerID = f.FarmerID,
                        FarmerCode = f.FarmerCode,
                        FullName = f.FullName,
                        ContactNumber = f.ContactNumber,
                        Village = f.Village,
                        IsActive = f.IsActive
                    })
                    .OrderBy(f => f.FarmerCode)
                    .ToListAsync();

                return farmers;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, $"Error searching farmers with term: {searchTerm}");
                throw;
            }
        }
    }
}