﻿using DairyERP.Data;
using DairyERP.Interfaces;
using DairyERP.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace DairyERP.Services
{
    public class CollectionService : ICollectionService
    {
        private readonly DairyDbContext _context;
        private readonly ILogger<CollectionService> _logger;

        public CollectionService(DairyDbContext context, ILogger<CollectionService> logger)
        {
            _context = context;
            _logger = logger;
        }

        public async Task<MilkCollection> RecordCollectionAsync(MilkCollection collection)
        {
            try
            {
                // Validate farmer exists
                var farmer = await _context.Farmers.FindAsync(collection.FarmerID);
                if (farmer == null)
                    throw new ArgumentException($"Farmer with ID {collection.FarmerID} not found");

                if (!farmer.IsActive)
                    throw new ArgumentException($"Farmer {farmer.FullName} is not active");

                // Set default values if not provided
                collection.CreatedAt = DateTime.UtcNow;
                collection.CollectionDate = collection.CollectionDate.Date;

                _context.MilkCollections.Add(collection);
                await _context.SaveChangesAsync();

                _logger.LogInformation($"Recorded collection for Farmer {farmer.FarmerCode}: {collection.Quantity}L");

                return collection;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error recording milk collection");
                throw;
            }
        }

        public async Task<List<MilkCollection>> GetDailyCollectionReportAsync(DateTime date, int? centerId)
        {
            try
            {
                var query = _context.MilkCollections
                    .Include(c => c.Farmer)
                    .Where(c => c.CollectionDate.Date == date.Date);

                if (centerId.HasValue)
                {
                    // If you have center logic, add it here
                    // query = query.Where(c => c.CenterID == centerId.Value);
                }

                var collections = await query
                    .OrderBy(c => c.Shift)
                    .ThenBy(c => c.Farmer.FarmerCode)
                    .ToListAsync();

                return collections;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting daily collection report");
                throw;
            }
        }

        public async Task<List<FarmerCollectionSummary>> GetFarmerCollectionSummaryAsync(
            int farmerId,
            DateTime fromDate,
            DateTime toDate)
        {
            try
            {
                var collections = await _context.MilkCollections
                    .Where(c => c.FarmerID == farmerId &&
                                c.CollectionDate.Date >= fromDate.Date &&
                                c.CollectionDate.Date <= toDate.Date)
                    .GroupBy(c => c.CollectionDate.Date)
                    .Select(g => new FarmerCollectionSummary
                    {
                        Date = g.Key,
                        TotalQuantity = g.Sum(c => c.Quantity),
                        AverageFat = g.Average(c => c.FatPercentage),
                        TotalAmount = g.Sum(c => c.TotalAmount)
                    })
                    .OrderByDescending(s => s.Date)
                    .ToListAsync();

                return collections;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error getting farmer collection summary");
                throw;
            }
        }
    }
}

// Note: FarmerCollectionSummary class is now defined in ICollectionService.cs