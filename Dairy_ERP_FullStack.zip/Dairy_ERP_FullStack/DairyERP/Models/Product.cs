﻿using System.ComponentModel.DataAnnotations;

namespace DairyERP.Models
{
    public class Product
    {
        [Key]
        public int ProductID { get; set; }

        [Required]
        [StringLength(20)]
        public string ProductCode { get; set; }

        [Required]
        [StringLength(200)]
        public string ProductName { get; set; }

        [StringLength(100)]
        public string Category { get; set; }

        [StringLength(50)]
        public string UnitType { get; set; }

        [Range(0, 999999)]
        public decimal PurchaseRate { get; set; }

        [Range(0, 999999)]
        public decimal SellingRate { get; set; }

        [Range(0, 100)]
        public decimal GSTPercentage { get; set; }

        public string Description { get; set; }

        public bool IsActive { get; set; } = true;
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;
    }
}