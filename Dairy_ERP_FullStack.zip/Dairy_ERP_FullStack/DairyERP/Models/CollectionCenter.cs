﻿using System.ComponentModel.DataAnnotations;

namespace DairyERP.Models
{
    public class CollectionCenter
    {
        [Key]
        public int CenterID { get; set; }

        [Required]
        [StringLength(20)]
        public string CenterCode { get; set; } = string.Empty;

        [Required]
        [StringLength(200)]
        public string CenterName { get; set; } = string.Empty;

        [StringLength(500)]
        public string Location { get; set; } = string.Empty;

        [StringLength(200)]
        public string InchargeName { get; set; } = string.Empty;

        [StringLength(20)]
        public string ContactNumber { get; set; } = string.Empty;

        [Range(0, 999999)]
        public decimal Capacity { get; set; }

        public bool IsActive { get; set; } = true;

        // FIX: Initialize the collection
        public virtual ICollection<MilkCollection> MilkCollections { get; set; } = new List<MilkCollection>();
    }
}