﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DairyERP.Models
{
    public class SalesInvoice
    {
        [Key]
        public int InvoiceID { get; set; }

        [Required]
        [StringLength(50)]
        public string InvoiceNumber { get; set; }

        [Required]
        public DateTime InvoiceDate { get; set; } = DateTime.UtcNow;

        [ForeignKey("Customer")]
        public int? CustomerID { get; set; }

        [StringLength(200)]
        public string CustomerName { get; set; }

        [StringLength(500)]
        public string CustomerAddress { get; set; }

        [StringLength(20)]
        public string CustomerPhone { get; set; }

        [StringLength(100)]
        public string CustomerGST { get; set; }

        [Range(0, 10000000)]
        public decimal SubTotal { get; set; }

        [Range(0, 1000000)]
        public decimal GSTAmount { get; set; }

        [Range(0, 1000000)]
        public decimal TotalAmount { get; set; }

        public decimal? Discount { get; set; }
        public decimal? RoundOff { get; set; }

        [Range(0, 10000000)]
        public decimal NetAmount { get; set; }

        [StringLength(20)]
        public string PaymentStatus { get; set; } = "Pending"; // Pending/Partial/Paid

        [StringLength(20)]
        public string PaymentMode { get; set; } // Cash/Card/UPI/Cheque

        public string Remarks { get; set; }
        public int CreatedBy { get; set; }
        public DateTime CreatedDate { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual Customer Customer { get; set; }
        public virtual ICollection<InvoiceDetail> InvoiceDetails { get; set; }
    }
}
