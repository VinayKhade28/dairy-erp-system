﻿using System.ComponentModel.DataAnnotations;

namespace DairyERP.Models
{
    public class Customer
    {
        [Key]
        public int CustomerID { get; set; }

        [Required]
        [StringLength(20)]
        public string CustomerCode { get; set; }

        [Required]
        [StringLength(200)]
        public string CustomerName { get; set; }

        [StringLength(500)]
        public string Address { get; set; }

        [StringLength(20)]
        public string Phone { get; set; }

        [StringLength(100)]
        [EmailAddress]
        public string Email { get; set; }

        [StringLength(100)]
        public string GSTNumber { get; set; }

        [StringLength(100)]
        public string PANNumber { get; set; }

        public decimal CreditLimit { get; set; }
        public decimal OutstandingBalance { get; set; }

        public bool IsActive { get; set; } = true;
        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual ICollection<SalesInvoice> SalesInvoices { get; set; }
    }
}
