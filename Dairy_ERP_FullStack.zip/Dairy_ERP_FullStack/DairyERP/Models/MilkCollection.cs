﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DairyERP.Models
{
    public class MilkCollection
    {
        [Key]
        public int CollectionID { get; set; }

        [Required]
        [ForeignKey("Farmer")]
        public int FarmerID { get; set; }

        [ForeignKey("CollectionCenter")]
        public int? CenterID { get; set; }

        [Required]
        public DateTime CollectionDate { get; set; } = DateTime.UtcNow;

        [Required]
        [Range(0.1, 1000)]
        public decimal Quantity { get; set; }

        [Range(0, 10)]
        public decimal? FatPercentage { get; set; }

        [Range(0, 10)]
        public decimal? SNFPercentage { get; set; }

        [Range(0, 1000)]
        public decimal? RatePerLiter { get; set; }

        // CHANGE THIS: From 'Amount' to 'TotalAmount'
        [NotMapped] // This property is calculated, not stored in DB
        public decimal? TotalAmount
        {
            get
            {
                if (Quantity > 0 && RatePerLiter.HasValue)
                    return Quantity * RatePerLiter.Value;
                return null;
            }
        }

        [StringLength(20)]
        public string Shift { get; set; } = "Morning";

        [StringLength(500)]
        public string Remarks { get; set; }

        public bool IsPaid { get; set; } = false;
        public DateTime? PaymentDate { get; set; }
        public int? CollectedBy { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.UtcNow;

        // Navigation properties
        public virtual Farmer Farmer { get; set; }
        public virtual CollectionCenter CollectionCenter { get; set; }
        public virtual User Collector { get; set; }
    }
}