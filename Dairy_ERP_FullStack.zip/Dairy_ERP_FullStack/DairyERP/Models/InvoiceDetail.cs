﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DairyERP.Models
{
    public class InvoiceDetail
    {
        [Key]
        public int DetailID { get; set; }

        [Required]
        [ForeignKey("SalesInvoice")]
        public int InvoiceID { get; set; }

        [ForeignKey("Product")]
        public int ProductID { get; set; }

        [Required]
        [StringLength(200)]
        public string ProductName { get; set; }

        [StringLength(50)]
        public string UnitType { get; set; }

        [Range(0.01, 10000)]
        public decimal Quantity { get; set; }

        [Range(0, 10000)]
        public decimal Rate { get; set; }

        [Range(0, 1000000)]
        public decimal Amount { get; set; }

        [Range(0, 100)]
        public decimal GSTPercentage { get; set; }

        [Range(0, 100000)]
        public decimal GSTAmount { get; set; }

        public decimal Discount { get; set; }
        public decimal NetAmount { get; set; }

        // Navigation properties
        public virtual SalesInvoice SalesInvoice { get; set; }
        public virtual Product Product { get; set; }
    }
}