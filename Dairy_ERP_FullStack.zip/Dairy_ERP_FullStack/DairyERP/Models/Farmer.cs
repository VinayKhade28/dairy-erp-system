﻿using System.ComponentModel.DataAnnotations;

namespace DairyERP.Models
{
    public class Farmer
    {
        [Key]
        public int FarmerID { get; set; }

        [Required]
        [StringLength(50)]
        public string FarmerCode { get; set; }

        [Required]
        [StringLength(200)]
        public string FullName { get; set; }

        [StringLength(20)]
        public string ContactNumber { get; set; }

        [StringLength(500)]
        public string Address { get; set; }

        [StringLength(100)]
        public string Village { get; set; }

        [StringLength(50)]
        public string BankAccountNumber { get; set; }

        [StringLength(20)]
        public string IFSCode { get; set; }

        public DateTime RegistrationDate { get; set; } = DateTime.UtcNow;
        public bool IsActive { get; set; } = true;

        // Navigation properties
        public virtual ICollection<MilkCollection> MilkCollections { get; set; }
    }
}