﻿using DairyERP.Data;
using DairyERP.Models;
using Microsoft.EntityFrameworkCore;

namespace DairyERP.Data
{
    public static class SeedData
    {
        public static async Task Initialize(DairyDbContext context)
        {
            // Ensure database is created
            await context.Database.EnsureCreatedAsync();

            // Seed Users if none exist
            if (!await context.Users.AnyAsync())
            {
                context.Users.AddRange(
                    new User
                    {
                        Username = "admin",
                        PasswordHash = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("admin123")),
                        FullName = "Administrator",
                        Email = "admin@dairyerp.com",
                        Role = "Admin",
                        IsActive = true
                    },
                    new User
                    {
                        Username = "manager",
                        PasswordHash = Convert.ToBase64String(System.Text.Encoding.UTF8.GetBytes("manager123")),
                        FullName = "Manager",
                        Email = "manager@dairyerp.com",
                        Role = "Manager",
                        IsActive = true
                    }
                );
                await context.SaveChangesAsync();
            }

            // Seed Collection Centers if none exist
            if (!await context.CollectionCenters.AnyAsync())
            {
                context.CollectionCenters.AddRange(
                    new CollectionCenter
                    {
                        CenterCode = "CC001",
                        CenterName = "Main Collection Center",
                        Location = "Main Road, City",
                        InchargeName = "John Doe",
                        ContactNumber = "9876543210",
                        Capacity = 5000,
                        IsActive = true
                    },
                    new CollectionCenter
                    {
                        CenterCode = "CC002",
                        CenterName = "North Zone Center",
                        Location = "North Area",
                        InchargeName = "Jane Smith",
                        ContactNumber = "9876543211",
                        Capacity = 3000,
                        IsActive = true
                    }
                );
                await context.SaveChangesAsync();
            }

            // Seed Products if none exist
            if (!await context.Products.AnyAsync())
            {
                context.Products.AddRange(
                    new Product
                    {
                        ProductCode = "P001",
                        ProductName = "Cow Milk",
                        Category = "Milk",
                        UnitType = "Liter",
                        PurchaseRate = 45.00m,
                        SellingRate = 60.00m,
                        GSTPercentage = 0,
                        IsActive = true
                    },
                    new Product
                    {
                        ProductCode = "P002",
                        ProductName = "Buffalo Milk",
                        Category = "Milk",
                        UnitType = "Liter",
                        PurchaseRate = 55.00m,
                        SellingRate = 70.00m,
                        GSTPercentage = 0,
                        IsActive = true
                    },
                    new Product
                    {
                        ProductCode = "P003",
                        ProductName = "Ghee",
                        Category = "Dairy Product",
                        UnitType = "Kg",
                        PurchaseRate = 500.00m,
                        SellingRate = 600.00m,
                        GSTPercentage = 5,
                        IsActive = true
                    }
                );
                await context.SaveChangesAsync();
            }

            // Seed Customers if none exist
            if (!await context.Customers.AnyAsync())
            {
                context.Customers.AddRange(
                    new Customer
                    {
                        CustomerCode = "CUST001",
                        CustomerName = "Retail Store 1",
                        Address = "Market Street, City",
                        Phone = "9876543212",
                        Email = "store1@example.com",
                        GSTNumber = "GSTIN001",
                        IsActive = true
                    },
                    new Customer
                    {
                        CustomerCode = "CUST002",
                        CustomerName = "Hotel Grand",
                        Address = "Main Road, City",
                        Phone = "9876543213",
                        Email = "hotel@example.com",
                        GSTNumber = "GSTIN002",
                        IsActive = true
                    }
                );
                await context.SaveChangesAsync();
            }

            // Seed Sample Farmers if none exist
            if (!await context.Farmers.AnyAsync())
            {
                context.Farmers.AddRange(
                    new Farmer
                    {
                        FarmerCode = "F001",
                        FullName = "Rajesh Kumar",
                        ContactNumber = "9876543220",
                        Village = "Village A",
                        BankAccountNumber = "123456789012",
                        IsActive = true
                    },
                    new Farmer
                    {
                        FarmerCode = "F002",
                        FullName = "Suresh Patel",
                        ContactNumber = "9876543221",
                        Village = "Village B",
                        BankAccountNumber = "123456789013",
                        IsActive = true
                    }
                );
                await context.SaveChangesAsync();
            }
        }
    }
}