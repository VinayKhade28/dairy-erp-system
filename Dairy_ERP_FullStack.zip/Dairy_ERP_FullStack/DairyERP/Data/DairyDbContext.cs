﻿using Microsoft.EntityFrameworkCore;
using DairyERP.Models;

namespace DairyERP.Data
{
    public class DairyDbContext : DbContext
    {
        public DairyDbContext(DbContextOptions<DairyDbContext> options)
            : base(options) { }

        public DbSet<User> Users { get; set; }
        public DbSet<Farmer> Farmers { get; set; }
        public DbSet<MilkCollection> MilkCollections { get; set; }
        public DbSet<CollectionCenter> CollectionCenters { get; set; }
        public DbSet<Product> Products { get; set; }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<SalesInvoice> SalesInvoices { get; set; }
        public DbSet<InvoiceDetail> InvoiceDetails { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // User configuration
            modelBuilder.Entity<User>()
                .HasIndex(u => u.Username)
                .IsUnique();

            // Farmer configuration
            modelBuilder.Entity<Farmer>()
                .HasIndex(f => f.FarmerCode)
                .IsUnique();

            // CollectionCenter configuration
            modelBuilder.Entity<CollectionCenter>()
                .HasIndex(c => c.CenterCode)
                .IsUnique();

            // Product configuration
            modelBuilder.Entity<Product>()
                .HasIndex(p => p.ProductCode)
                .IsUnique();

            // Customer configuration
            modelBuilder.Entity<Customer>()
                .HasIndex(c => c.CustomerCode)
                .IsUnique();

            // SalesInvoice configuration
            modelBuilder.Entity<SalesInvoice>()
                .HasIndex(s => s.InvoiceNumber)
                .IsUnique();

            // MilkCollection configuration
            modelBuilder.Entity<MilkCollection>()
                .HasIndex(c => c.CollectionDate);

            // Configure relationships
            modelBuilder.Entity<MilkCollection>()
                .HasOne(m => m.Farmer)
                .WithMany(f => f.MilkCollections)
                .HasForeignKey(m => m.FarmerID)
                .OnDelete(DeleteBehavior.Restrict);

            modelBuilder.Entity<MilkCollection>()
                .HasOne(m => m.CollectionCenter)
                .WithMany(c => c.MilkCollections)
                .HasForeignKey(m => m.CenterID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<SalesInvoice>()
                .HasOne(s => s.Customer)
                .WithMany(c => c.SalesInvoices)
                .HasForeignKey(s => s.CustomerID)
                .OnDelete(DeleteBehavior.SetNull);

            modelBuilder.Entity<InvoiceDetail>()
                .HasOne(d => d.SalesInvoice)
                .WithMany(s => s.InvoiceDetails)
                .HasForeignKey(d => d.InvoiceID)
                .OnDelete(DeleteBehavior.Cascade);

            // Set default values
            modelBuilder.Entity<User>()
                .Property(u => u.CreatedDate)
                .HasDefaultValueSql("GETUTCDATE()");

            modelBuilder.Entity<Farmer>()
                .Property(f => f.RegistrationDate)
                .HasDefaultValueSql("GETUTCDATE()");

            modelBuilder.Entity<Product>()
                .Property(p => p.CreatedDate)
                .HasDefaultValueSql("GETUTCDATE()");

            modelBuilder.Entity<Customer>()
                .Property(c => c.RegistrationDate)
                .HasDefaultValueSql("GETUTCDATE()");

            modelBuilder.Entity<SalesInvoice>()
                .Property(s => s.CreatedDate)
                .HasDefaultValueSql("GETUTCDATE()");

            modelBuilder.Entity<MilkCollection>()
                .Property(c => c.CreatedAt)
                .HasDefaultValueSql("GETUTCDATE()");
        }
    }
}