// src/utils/diagnostics.ts
export async function runDiagnostics() {
  console.group('🔍 Running Diagnostics');
  
  // 1. Check environment
  console.log('Environment Variables:');
  console.log('- REACT_APP_API_URL:', process.env.REACT_APP_API_URL);
  console.log('- NODE_ENV:', process.env.NODE_ENV);
  
  // 2. Test direct fetch
  console.log('\nTesting direct fetch...');
  try {
    const testUrl = process.env.REACT_APP_API_URL 
      ? `${process.env.REACT_APP_API_URL}/Auth/test`
      : 'http://localhost:5000/api/Auth/test';
    
    console.log('Testing URL:', testUrl);
    
    const response = await fetch(testUrl, {
      method: 'GET',
      mode: 'cors',
      credentials: 'include'
    });
    
    console.log('Response Status:', response.status);
    console.log('Response Headers:', Object.fromEntries(response.headers.entries()));
    
    if (response.ok) {
      const data = await response.json();
      console.log('Response Data:', data);
    }
  } catch (error: any) {
    console.error('Fetch Error:', error.message);
  }
  
  // 3. Test with axios
  console.log('\nTesting with axios...');
  try {
    const api = (await import('../services/api')).default;
    const response = await api.get('/Auth/test');
    console.log('Axios Response:', response.status, response.data);
  } catch (error: any) {
    console.error('Axios Error:', error.message);
    if (error.response) {
      console.error('Error Details:', error.response.data);
    }
  }
  
  // 4. Check localStorage
  console.log('\nLocalStorage:');
  console.log('- Token exists:', !!localStorage.getItem('token'));
  console.log('- User exists:', !!localStorage.getItem('user'));
  
  console.groupEnd();
}

// Run in browser console
(window as any).runDiagnostics = runDiagnostics;